window.__imported__ = window.__imported__ || {};
window.__imported__["slider/layers.json.js"] = [
	{
		"id": 5640,
		"name": "Bg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1920,
			"height": 1136
		},
		"maskFrame": null,
		"image": {
			"path": "images/Bg.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 1920,
				"height": 1136
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1988695100"
	},
	{
		"id": 5693,
		"name": "cards",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1920,
			"height": 1136
		},
		"maskFrame": null,
		"image": null,
		"imageType": null,
		"children": [
			{
				"id": 5692,
				"name": "card1",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 1920,
					"height": 1136
				},
				"maskFrame": null,
				"image": {
					"path": "images/card1.png",
					"frame": {
						"x": 25,
						"y": 28,
						"width": 580,
						"height": 897
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "990146907"
			},
			{
				"id": 5660,
				"name": "card2",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 1920,
					"height": 1136
				},
				"maskFrame": null,
				"image": {
					"path": "images/card2.png",
					"frame": {
						"x": 669,
						"y": 30,
						"width": 580,
						"height": 897
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1312609480"
			},
			{
				"id": 5685,
				"name": "card3",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 1920,
					"height": 1136
				},
				"maskFrame": null,
				"image": {
					"path": "images/card3.png",
					"frame": {
						"x": 1310,
						"y": 30,
						"width": 580,
						"height": 897
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "2077050872"
			}
		],
		"modification": "1284472079"
	}
]