window.__imported__ = window.__imported__ || {};
window.__imported__["example3_swipe/layers.json.js"] = [
  {
    "maskFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "id" : "467D259F-657A-4BEC-B60C-B8649B3A5542",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/bg-467D259F-657A-4BEC-B60C-B8649B3A5542.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "bg"
  },
  {
    "maskFrame" : null,
    "id" : "798508F9-2530-4983-865D-078792D52551",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/delete-798508F9-2530-4983-865D-078792D52551.png",
      "frame" : {
        "y" : 127,
        "x" : 2,
        "width" : 748,
        "height" : 151
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 127,
      "x" : 2,
      "width" : 748,
      "height" : 151
    },
    "name" : "delete"
  },
  {
    "maskFrame" : null,
    "id" : "C98AA120-6BD4-4158-8C00-3AE9675BED77",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/message-C98AA120-6BD4-4158-8C00-3AE9675BED77.png",
      "frame" : {
        "y" : 127,
        "x" : 0,
        "width" : 750,
        "height" : 153
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 127,
      "x" : 0,
      "width" : 750,
      "height" : 153
    },
    "name" : "message"
  },
  {
    "maskFrame" : null,
    "id" : "56441F68-B18C-4BEC-AC43-57EBA8202E03",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/top_nav-56441F68-B18C-4BEC-AC43-57EBA8202E03.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 127
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 127
    },
    "name" : "top_nav"
  }
]