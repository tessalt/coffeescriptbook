window.__imported__ = window.__imported__ || {};
window.__imported__["swipe/layers.json.js"] = [
	{
		"id": 1840,
		"name": "bg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1136
		},
		"maskFrame": null,
		"image": {
			"path": "images/bg.png",
			"frame": {
				"x": 0,
				"y": 40,
				"width": 640,
				"height": 1096
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "863442307"
	},
	{
		"id": 1739,
		"name": "delete",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1136
		},
		"maskFrame": null,
		"image": {
			"path": "images/delete.png",
			"frame": {
				"x": 0,
				"y": 125,
				"width": 640,
				"height": 151
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1800021914"
	},
	{
		"id": 1708,
		"name": "message",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1136
		},
		"maskFrame": null,
		"image": {
			"path": "images/message.png",
			"frame": {
				"x": 0,
				"y": 127,
				"width": 640,
				"height": 151
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "733022571"
	},
	{
		"id": 1753,
		"name": "Navigation_Bar",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1136
		},
		"maskFrame": null,
		"image": {
			"path": "images/Navigation_Bar.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 640,
				"height": 129
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "727677044"
	}
]