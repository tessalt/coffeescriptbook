window.__imported__ = window.__imported__ || {};
window.__imported__["example3_swipe2/layers.json.js"] = [
	{
		"id": 5,
		"name": "bg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": null,
		"imageType": null,
		"children": [
			{
				"id": 52,
				"name": "Navigation_Bar",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/Navigation_Bar.png",
					"frame": {
						"x": 0,
						"y": 0,
						"width": 750,
						"height": 129
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "158714615"
			},
			{
				"id": 46,
				"name": "message",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/message.png",
					"frame": {
						"x": 0,
						"y": 127,
						"width": 750,
						"height": 151
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "2075231165"
			},
			{
				"id": 38,
				"name": "delete",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/delete.png",
					"frame": {
						"x": 0,
						"y": 125,
						"width": 750,
						"height": 151
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "117909762"
			},
			{
				"id": 34,
				"name": "bg",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/bg.png",
					"frame": {
						"x": 0,
						"y": 0,
						"width": 750,
						"height": 1334
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "57585629"
			}
		],
		"modification": "503784321"
	}
]