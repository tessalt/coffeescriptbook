window.__imported__ = window.__imported__ || {};
window.__imported__["Camera Roll/layers.json.js"] = [
	{
		"id": 1952,
		"name": "img1",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1136
		},
		"maskFrame": null,
		"image": {
			"path": "images/img1.png",
			"frame": {
				"x": 0,
				"y": 129,
				"width": 160,
				"height": 160
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "2013785126"
	},
	{
		"id": 1954,
		"name": "img2",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1136
		},
		"maskFrame": null,
		"image": {
			"path": "images/img2.png",
			"frame": {
				"x": 160,
				"y": 129,
				"width": 160,
				"height": 160
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "660475428"
	},
	{
		"id": 1956,
		"name": "img3",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1136
		},
		"maskFrame": null,
		"image": {
			"path": "images/img3.png",
			"frame": {
				"x": 320,
				"y": 129,
				"width": 160,
				"height": 160
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "2046143967"
	},
	{
		"id": 1958,
		"name": "img4",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1136
		},
		"maskFrame": null,
		"image": {
			"path": "images/img4.png",
			"frame": {
				"x": 480,
				"y": 129,
				"width": 160,
				"height": 160
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "895513631"
	}
]