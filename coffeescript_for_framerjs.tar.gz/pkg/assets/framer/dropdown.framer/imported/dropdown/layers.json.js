window.__imported__ = window.__imported__ || {};
window.__imported__["dropdown/layers.json.js"] = [
	{
		"id": 19,
		"name": "Dropdown",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 641,
			"height": 609
		},
		"maskFrame": null,
		"image": null,
		"imageType": null,
		"children": [
			{
				"id": 18,
				"name": "Top_bar",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 641,
					"height": 609
				},
				"maskFrame": null,
				"image": {
					"path": "images/Top_bar.png",
					"frame": {
						"x": 0,
						"y": 0,
						"width": 641,
						"height": 129
					}
				},
				"imageType": "png",
				"children": [
					{
						"id": 20,
						"name": "menuIcon",
						"layerFrame": {
							"x": 0,
							"y": 0,
							"width": 641,
							"height": 609
						},
						"maskFrame": null,
						"image": {
							"path": "images/menuIcon.png",
							"frame": {
								"x": 11,
								"y": 49,
								"width": 66,
								"height": 66
							}
						},
						"imageType": "png",
						"children": [
							
						],
						"modification": "220070460"
					}
				],
				"modification": "803375416"
			},
			{
				"id": 22,
				"name": "menuContent",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 641,
					"height": 609
				},
				"maskFrame": null,
				"image": {
					"path": "images/menuContent.png",
					"frame": {
						"x": 0,
						"y": 128,
						"width": 640,
						"height": 481
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "106206454"
			}
		],
		"modification": "1231201625"
	}
]