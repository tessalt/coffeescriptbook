window.__imported__ = window.__imported__ || {};
window.__imported__["example2_dropdown/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "9834C19A-78C7-4FFD-8344-CB55DC1C0834",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "4ADEAF2E-859C-4DAC-A1C2-31E6EA30D173",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "2A7FE607-FA78-4433-9B34-0C8F0F5F0DD3",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/menu_icon-2A7FE607-FA78-4433-9B34-0C8F0F5F0DD3.png",
              "frame" : {
                "y" : 66,
                "x" : 29,
                "width" : 39,
                "height" : 29
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 66,
              "x" : 29,
              "width" : 39,
              "height" : 29
            },
            "name" : "menu_icon"
          }
        ],
        "image" : {
          "path" : "images\/top_bar-4ADEAF2E-859C-4DAC-A1C2-31E6EA30D173.png",
          "frame" : {
            "y" : -1,
            "x" : 0,
            "width" : 752,
            "height" : 129
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : -1,
          "x" : 0,
          "width" : 752,
          "height" : 129
        },
        "name" : "top_bar"
      },
      {
        "maskFrame" : null,
        "id" : "F690BFCA-B7DF-4F9B-9338-31D759DE120B",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/menu_content-F690BFCA-B7DF-4F9B-9338-31D759DE120B.png",
          "frame" : {
            "y" : 128,
            "x" : 0,
            "width" : 753,
            "height" : 481
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 128,
          "x" : 0,
          "width" : 753,
          "height" : 481
        },
        "name" : "menu_content"
      }
    ],
    "image" : {
      "path" : "images\/dropdown-9834C19A-78C7-4FFD-8344-CB55DC1C0834.png",
      "frame" : {
        "y" : -1,
        "x" : 0,
        "width" : 753,
        "height" : 610
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : -1,
      "x" : 0,
      "width" : 753,
      "height" : 610
    },
    "name" : "dropdown"
  }
]