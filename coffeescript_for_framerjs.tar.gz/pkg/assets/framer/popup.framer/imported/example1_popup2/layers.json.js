window.__imported__ = window.__imported__ || {};
window.__imported__["example1_popup2/layers.json.js"] = [
  {
    "maskFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "id" : "467D259F-657A-4BEC-B60C-B8649B3A5542",
    "visible" : true,
    "children" : [

    ],
    "image" : {
      "path" : "images\/bg-467D259F-657A-4BEC-B60C-B8649B3A5542.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "bg"
  },
  {
    "maskFrame" : null,
    "id" : "C8C4A3B3-B9F7-4579-89AD-7E65563620BF",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "BCEA5EB2-97CB-4926-8828-0B85CFD92CD1",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Achievement_Icon-BCEA5EB2-97CB-4926-8828-0B85CFD92CD1.png",
          "frame" : {
            "y" : 477,
            "x" : 247,
            "width" : 241,
            "height" : 246
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 477,
          "x" : 247,
          "width" : 241,
          "height" : 246
        },
        "name" : "Achievement_Icon"
      }
    ],
    "image" : {
      "path" : "images\/popup-C8C4A3B3-B9F7-4579-89AD-7E65563620BF.png",
      "frame" : {
        "y" : 260,
        "x" : 50,
        "width" : 650,
        "height" : 815
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 260,
      "x" : 50,
      "width" : 650,
      "height" : 815
    },
    "name" : "popup"
  }
]