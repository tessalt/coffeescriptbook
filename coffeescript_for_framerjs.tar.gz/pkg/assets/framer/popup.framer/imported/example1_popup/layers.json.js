window.__imported__ = window.__imported__ || {};
window.__imported__["example1_popup/layers.json.js"] = [
	{
		"id": 5,
		"name": "bg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/bg.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 750,
				"height": 1334
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1223915182"
	},
	{
		"id": 9,
		"name": "mustache",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/mustache.png",
			"frame": {
				"x": 257,
				"y": 548,
				"width": 240,
				"height": 240
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "964625127"
	},
	{
		"id": 23,
		"name": "popup",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 750,
			"height": 1334
		},
		"maskFrame": null,
		"image": {
			"path": "images/popup.png",
			"frame": {
				"x": 51,
				"y": 240,
				"width": 652,
				"height": 813
			}
		},
		"imageType": "png",
		"children": [
			{
				"id": 15,
				"name": "close",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/close.png",
					"frame": {
						"x": 620,
						"y": 298,
						"width": 24,
						"height": 23
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "1224034221"
			},
			{
				"id": 22,
				"name": "badge",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"maskFrame": null,
				"image": {
					"path": "images/badge.png",
					"frame": {
						"x": 257,
						"y": 418,
						"width": 240,
						"height": 326
					}
				},
				"imageType": "png",
				"children": [
					
				],
				"modification": "426155589"
			}
		],
		"modification": "1641382351"
	}
]