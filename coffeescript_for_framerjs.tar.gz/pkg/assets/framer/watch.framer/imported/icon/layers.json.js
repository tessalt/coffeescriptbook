window.__imported__ = window.__imported__ || {};
window.__imported__["icon/layers.json.js"] = [
	{
		"id": 6,
		"name": "icon",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 196,
			"height": 196
		},
		"maskFrame": null,
		"image": {
			"path": "images/icon.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 196,
				"height": 196
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "525900364"
	}
]