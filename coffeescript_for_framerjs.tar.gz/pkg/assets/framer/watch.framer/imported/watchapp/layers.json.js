window.__imported__ = window.__imported__ || {};
window.__imported__["watchapp/layers.json.js"] = [
	{
		"id": 31,
		"name": "notification",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 313,
			"height": 292
		},
		"maskFrame": null,
		"image": null,
		"imageType": null,
		"children": [
			{
				"id": 24,
				"name": "content",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 313,
					"height": 292
				},
				"maskFrame": null,
				"image": null,
				"imageType": null,
				"children": [
					{
						"id": 25,
						"name": "screen",
						"layerFrame": {
							"x": 0,
							"y": 0,
							"width": 313,
							"height": 292
						},
						"maskFrame": null,
						"image": null,
						"imageType": null,
						"children": [
							{
								"id": 15,
								"name": "head",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 313,
									"height": 292
								},
								"maskFrame": null,
								"image": {
									"path": "images/head.png",
									"frame": {
										"x": 1,
										"y": 0,
										"width": 312,
										"height": 62
									}
								},
								"imageType": "png",
								"children": [
									
								],
								"modification": "874705090"
							},
							{
								"id": 11,
								"name": "content",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 313,
									"height": 292
								},
								"maskFrame": null,
								"image": {
									"path": "images/content.png",
									"frame": {
										"x": 1,
										"y": 0,
										"width": 312,
										"height": 207
									}
								},
								"imageType": "png",
								"children": [
									
								],
								"modification": "1700663144"
							}
						],
						"modification": "674658564"
					}
				],
				"modification": "228351138"
			},
			{
				"id": 49,
				"name": "button",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 313,
					"height": 292
				},
				"maskFrame": null,
				"image": null,
				"imageType": null,
				"children": [
					{
						"id": 48,
						"name": "screen-2",
						"layerFrame": {
							"x": 0,
							"y": 0,
							"width": 313,
							"height": 292
						},
						"maskFrame": null,
						"image": null,
						"imageType": null,
						"children": [
							{
								"id": 43,
								"name": "content-2",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 313,
									"height": 292
								},
								"maskFrame": null,
								"image": {
									"path": "images/content-2.png",
									"frame": {
										"x": 1,
										"y": 222,
										"width": 312,
										"height": 70
									}
								},
								"imageType": "png",
								"children": [
									
								],
								"modification": "1544674745"
							}
						],
						"modification": "319815240"
					}
				],
				"modification": "487146435"
			}
		],
		"modification": "653315505"
	}
]