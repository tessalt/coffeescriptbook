window.__imported__ = window.__imported__ || {};
window.__imported__["example4_watch/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "86130C6F-1365-4F69-B62D-95D94D9B0477",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "A20C5081-0F6C-42FD-9F86-9D9AC72FE6B5",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/button-A20C5081-0F6C-42FD-9F86-9D9AC72FE6B5.png",
          "frame" : {
            "y" : 224,
            "x" : 0,
            "width" : 312,
            "height" : 68
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 224,
          "x" : 0,
          "width" : 312,
          "height" : 68
        },
        "name" : "button"
      },
      {
        "maskFrame" : null,
        "id" : "E4135DDC-AD25-4EA6-93E8-F1B8774F93AD",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/content-E4135DDC-AD25-4EA6-93E8-F1B8774F93AD.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 312,
            "height" : 206
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 312,
          "height" : 206
        },
        "name" : "content"
      }
    ],
    "image" : {
      "path" : "images\/notification-86130C6F-1365-4F69-B62D-95D94D9B0477.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 312,
        "height" : 292
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 312,
      "height" : 292
    },
    "name" : "notification"
  }
]